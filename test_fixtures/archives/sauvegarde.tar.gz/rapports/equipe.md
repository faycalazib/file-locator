# Équipe

Le chef de quai coordonne le déchargement.